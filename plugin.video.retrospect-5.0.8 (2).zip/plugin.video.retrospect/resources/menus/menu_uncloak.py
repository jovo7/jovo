# SPDX-License-Identifier: CC-BY-NC-SA-4.0

import menu

with menu.Menu("Un-cloak Item") as m:
    m.toggle_cloak()
